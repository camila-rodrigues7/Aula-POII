/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifc.aula.aula2;

/**
 *
 * @author aluno
 */
public class matematicaTeste {
    public static void main (String[] args) {
        matematica m = new matematica();
       System.out.println(m.calculo(5.0, 6.5));
       System.out.println(m.calculo(10.0, 4));
       System.out.println(m.media(4, 6));
       System.out.println(m.media("4", "6.6"));
       
    
}
    
}
