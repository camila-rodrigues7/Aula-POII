/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.aula.ExercicioBanco;

import br.edu.ifc.aula.Veiculo.Veiculo;

/**
 *
 * @author aluno
 */
public class ContaBancariaTeste {
    public static void main(String[] args) {
        ContaBancaria c1 = new ContaBancaria();
        
        c1.setCliente("José");
        c1.setSaldo(100);
        
    }
